//
//  SampleLoggerSDK.h
//  SampleLoggerSDK
//
//  Created by Ganesh Manickam on 15/10/20.
//  Copyright © 2020 Ganesh Manickam. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for SampleLoggerSDK.
FOUNDATION_EXPORT double SampleLoggerSDKVersionNumber;

//! Project version string for SampleLoggerSDK.
FOUNDATION_EXPORT const unsigned char SampleLoggerSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SampleLoggerSDK/PublicHeader.h>


